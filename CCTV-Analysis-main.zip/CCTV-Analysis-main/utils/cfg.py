class CFG:
    THRESHOLD = 0.7